package com.example.class1

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.osmdroid.util.GeoPoint

class RenfeStationActivity : AppCompatActivity() {
    private val TAG = "RenfeStationActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_renfe_stations)

        // Crea una lista de estaciones manualmente
        val stationList = listOf(
            "GUADALAJARA" to GeoPoint(40.534668, -3.2985719),
            "AZUQUECA" to GeoPoint(40.56104, -3.265446),
            "COSLADA" to GeoPoint(40.4241947, -3.5602359),
            "MADRID-RECOLETOS" to GeoPoint(40.423371, -3.690995),
            "PIRAMIDES" to GeoPoint(40.402516, -3.711374),
            "MADRID-PRINCIPE PIO" to GeoPoint(40.421389, -3.718968),
            "EMBAJADORES" to GeoPoint(40.404609, -3.702592),
            "SOL" to GeoPoint(40.416856, -3.702904),
            "ASAMBLEA DE MADRID-ENTREVIAS" to GeoPoint(40.3814976, -3.667215),
            "VILLAVERDE ALTO" to GeoPoint(40.341622, -3.712565),
            "VILLAVERDE BAJO" to GeoPoint(40.3555397, -3.6832514),
            "SAN CRISTOBAL INDUSTRIAL" to GeoPoint(40.3320318, -3.6963666),
            "SAN CRISTOBAL DE LOS ANGELES" to GeoPoint(40.3419854, -3.683232),
            "ARAVACA" to GeoPoint(40.448345, -3.786191),
            "CUATRO VIENTOS" to GeoPoint(40.377714, -3.791574),
            "DOCE DE OCTUBRE" to GeoPoint(40.379224, -3.698976),
            "VALLECAS" to GeoPoint(40.382264, -3.624931),
            "EL POZO" to GeoPoint(40.3765168, -3.6564132),
            "SANTA EUGENIA" to GeoPoint(40.3877971, -3.6087501),
            "FUENCARRAL" to GeoPoint(40.5024656, -3.6817503),
            "Mirasierra" to GeoPoint(40.499759, -3.709755),
            "RAMON Y CAJAL" to GeoPoint(40.4880223, -3.6935145),
            "PITIS" to GeoPoint(40.4956316, -3.7256015),
            "MADRID-CHAMARTIN" to GeoPoint(40.4732797, -3.6818974),
            "ORCASITAS" to GeoPoint(40.367081, -3.704244),
            "PUENTE ALCOCER" to GeoPoint(40.350418, -3.705122),
            "AEROPUERTO T-4" to GeoPoint(40.491691, -3.593988),
            "FANJUL" to GeoPoint(40.38367, -3.768496),
            "LAS AGUILAS" to GeoPoint(40.381009, -3.780187),
            "MADRID-ATOCHA CERCANIAS" to GeoPoint(40.406556, -3.689508),
            "MENDEZ ALVARO" to GeoPoint(40.395419, -3.678137),
            "DELICIAS" to GeoPoint(40.400381, -3.692712),
            "MENDEZ ALVARO" to GeoPoint(40.395735, -3.677847),
            "MADRID-NUEVOS MINISTERIOS" to GeoPoint(40.446612, -3.692207),
            "ALUCHE" to GeoPoint(40.385738, -3.760807),
            "LAGUNA" to GeoPoint(40.399006, -3.744225),
            "EL GOLOSO" to GeoPoint(40.558808, -3.713966),
            "UNIVERSIDAD-CANTOBLANCO" to GeoPoint(40.543818, -3.700217),
            "UNIVERSIDAD PONTIFICIA DE COMILLAS" to GeoPoint(40.55412, -3.683267),
            "FUENTE DE LA MORA" to GeoPoint(40.484729, -3.662833),
            "VICALVARO" to GeoPoint(40.401043, -3.5952733),
            "VALDEBEBAS" to GeoPoint(40.48207, -3.616414),
            "VALDELASFUENTES" to GeoPoint(40.547425, -3.654149),
            "ALCOBENDAS SAN SEBASTIAN DE LOS REYES" to GeoPoint(40.546744, -3.635149),
            "MAJADAHONDA" to GeoPoint(40.474347, -3.845334),
            "POZUELO" to GeoPoint(40.447225, -3.800145),
            "EL BARRIAL-CENTRO COMERCIAL-POZUELO" to GeoPoint(40.465299, -3.807828),
            "LAS ROZAS" to GeoPoint(40.494215, -3.868181),
            "PINAR DE LAS ROZAS" to GeoPoint(40.522282, -3.882258),
            "TORRELODONES" to GeoPoint(40.574559, -3.956577),
            "EL ESCORIAL" to GeoPoint(40.585279, -4.132418),
            "LAS MATAS" to GeoPoint(40.552415, -3.896791),
            "SAN YAGO" to GeoPoint(40.617864, -4.031106),
            "LAS ZORRERAS-NAVALQUEJIGO" to GeoPoint(40.609265, -4.046336),
            "ARANJUEZ" to GeoPoint(40.0347255, -3.6182069),
            "PINTO" to GeoPoint(40.2429829, -3.7036534),
            "VALDEMORO" to GeoPoint(40.1958184, -3.6646737),
            "CIEMPOZUELOS" to GeoPoint(40.1590641, -3.610221),
            "VILLALBA DE GUADARRAMA" to GeoPoint(40.626522, -4.00812),
            "LOS NEGRALES" to GeoPoint(40.63856, -4.021915),
            "GALAPAGAR-LA NAVATA" to GeoPoint(40.600159, -3.981913),
            "ALPEDRETE" to GeoPoint(40.658096, -4.034996),
            "COLLADO MEDIANO" to GeoPoint(40.692757, -4.035894),
            "LOS MOLINOS-GUADARRAMA" to GeoPoint(40.706598, -4.067179),
            "CERCEDILLA" to GeoPoint(40.737516, -4.066481),
            "PUERTO DE NAVACERRADA" to GeoPoint(40.784445, -4.004772),
            "TRES CANTOS" to GeoPoint(40.598596, -3.7156),
            "COLMENAR VIEJO" to GeoPoint(40.645211, -3.776617),
            "LA GARENA" to GeoPoint(40.4807624, -3.3919677),
            "ALCALA DE HENARES" to GeoPoint(40.488976, -3.3664702),
            "ALCALA DE HENARES-UNIVERSIDAD" to GeoPoint(40.5054503, -3.3353684),
            "SAN FERNANDO DE HENARES" to GeoPoint(40.4424319, -3.5342411),
            "TORREJON DE ARDOZ" to GeoPoint(40.4547456, -3.4797065),
            "SOTO DEL HENARES" to GeoPoint(40.464383, -3.440614),
            "MECO" to GeoPoint(40.534668, -3.2985719),
            "GETAFE-SECTOR 3" to GeoPoint(40.288252, -3.737529),
            "GETAFE-CENTRO" to GeoPoint(40.309974, -3.733989),
            "LAS MARGARITAS" to GeoPoint(40.323041, -3.727278),
            "GETAFE-INDUSTRIAL" to GeoPoint(40.3055338, -3.7073714),
            "EL CASAR" to GeoPoint(40.3184029, -3.7092335),
            "LEGANES" to GeoPoint(40.328633, -3.771162),
            "PARQUE POLVORANCA" to GeoPoint(40.312544, -3.783546),
            "ZARZAQUEMADA" to GeoPoint(40.3409732, -3.7482259),
            "ALCORCON" to GeoPoint(40.350199, -3.831678),
            "LAS RETAMAS" to GeoPoint(40.341869, -3.842311),
            "SAN JOSE DE VALDERAS" to GeoPoint(40.356574, -3.815577),
            "MOSTOLES" to GeoPoint(40.328724, -3.863478),
            "MOSTOLES-EL SOTO" to GeoPoint(40.330971, -3.882441),
            "FUENLABRADA" to GeoPoint(40.283135, -3.799565),
            "LA SERNA-FUENLABRADA" to GeoPoint(40.296725, -3.792477),
            "HUMANES" to GeoPoint(40.255565, -3.828334),
            "PARLA" to GeoPoint(40.241032, -3.769312),
            "LOS COTOS" to GeoPoint(40.822239, -3.964546)
        )


        // Debug log para verificar los datos de la lista de estaciones
        stationList.forEach { station ->
            Log.d(TAG, "Station: ${station.first}, Location: ${station.second.latitude},${station.second.longitude}")
        }

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Crear y configurar el adaptador
        val adapter = RenfeStationAdapter(stationList)
        recyclerView.adapter = adapter

        // Inflar el diseño de la cabecera
        val headerView = LayoutInflater.from(this).inflate(R.layout.listview_header, recyclerView, false)
        adapter.setHeaderView(headerView)
    }
}