package com.example.class1

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.osmdroid.util.GeoPoint
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import android.os.Handler
private lateinit var handler: Handler
private lateinit var locationTextView: TextView


class MainActivity : AppCompatActivity(), LocationListener {
    private val TAG = "btaMainActivity"
    private lateinit var locationManager: LocationManager
    private var latestLocation: Location? = null
    private val locationPermissionCode = 2

    // List of RENFE stations with coordinates
    private val renfeStations: List<Pair<String, GeoPoint>> = listOf(
        Pair("GUADALAJARA", GeoPoint(40.534668, -3.2985719)),
        Pair("AZUQUECA", GeoPoint(40.56104, -3.265446)),
        Pair("COSLADA", GeoPoint(40.4241947, -3.5602359)),
        Pair("MADRID-RECOLETOS", GeoPoint(40.423371, -3.690995)),
        Pair("PIRAMIDES", GeoPoint(40.402516, -3.711374)),
        Pair("MADRID-PRINCIPE PIO", GeoPoint(40.421389, -3.718968)),
        Pair("EMBAJADORES", GeoPoint(40.404609, -3.702592)),
        Pair("SOL", GeoPoint(40.416856, -3.702904)),
        Pair("ASAMBLEA DE MADRID-ENTREVIAS", GeoPoint(40.3814976, -3.667215)),
        Pair("VILLAVERDE ALTO", GeoPoint(40.341622, -3.712565)),
        Pair("VILLAVERDE BAJO", GeoPoint(40.3555397, -3.6832514)),
        Pair("SAN CRISTOBAL INDUSTRIAL", GeoPoint(40.3320318, -3.6963666)),
        Pair("SAN CRISTOBAL DE LOS ANGELES", GeoPoint(40.3419854, -3.683232)),
        Pair("ARAVACA", GeoPoint(40.448345, -3.786191)),
        Pair("CUATRO VIENTOS", GeoPoint(40.377714, -3.791574)),
        Pair("DOCE DE OCTUBRE", GeoPoint(40.379224, -3.698976)),
        Pair("VALLECAS", GeoPoint(40.382264, -3.624931)),
        Pair("EL POZO", GeoPoint(40.3765168, -3.6564132)),
        Pair("SANTA EUGENIA", GeoPoint(40.3877971, -3.6087501)),
        Pair("FUENCARRAL", GeoPoint(40.5024656, -3.6817503)),
        Pair("Mirasierra", GeoPoint(40.499759, -3.709755)),
        Pair("RAMON Y CAJAL", GeoPoint(40.4880223, -3.6935145)),
        Pair("PITIS", GeoPoint(40.4956316, -3.7256015)),
        Pair("MADRID-CHAMARTIN", GeoPoint(40.4732797, -3.6818974)),
        Pair("ORCASITAS", GeoPoint(40.367081, -3.704244)),
        Pair("PUENTE ALCOCER", GeoPoint(40.350418, -3.705122)),
        Pair("AEROPUERTO T-4", GeoPoint(40.491691, -3.593988)),
        Pair("FANJUL", GeoPoint(40.38367, -3.768496)),
        Pair("LAS AGUILAS", GeoPoint(40.381009, -3.780187)),
        Pair("MADRID-ATOCHA CERCANIAS", GeoPoint(40.406556, -3.689508)),
        Pair("MENDEZ ALVARO", GeoPoint(40.395419, -3.678137)),
        Pair("DELICIAS", GeoPoint(40.400381, -3.692712)),
        Pair("MENDEZ ALVARO", GeoPoint(40.395735, -3.677847)),
        Pair("MADRID-NUEVOS MINISTERIOS", GeoPoint(40.446612, -3.692207)),
        Pair("ALUCHE", GeoPoint(40.385738, -3.760807)),
        Pair("LAGUNA", GeoPoint(40.399006, -3.744225)),
        Pair("EL GOLOSO", GeoPoint(40.558808, -3.713966)),
        Pair("UNIVERSIDAD-CANTOBLANCO", GeoPoint(40.543818, -3.700217)),
        Pair("UNIVERSIDAD PONTIFICIA DE COMILLAS", GeoPoint(40.55412, -3.683267)),
        Pair("FUENTE DE LA MORA", GeoPoint(40.484729, -3.662833)),
        Pair("VICALVARO", GeoPoint(40.401043, -3.5952733)),
        Pair("VALDEBEBAS", GeoPoint(40.48207, -3.616414)),
        Pair("VALDELASFUENTES", GeoPoint(40.547425, -3.654149)),
        Pair("ALCOBENDAS SAN SEBASTIAN DE LOS REYES", GeoPoint(40.546744, -3.635149)),
        Pair("MAJADAHONDA", GeoPoint(40.474347, -3.845334)),
        Pair("POZUELO", GeoPoint(40.447225, -3.800145)),
        Pair("EL BARRIAL-CENTRO COMERCIAL-POZUELO", GeoPoint(40.465299, -3.807828)),
        Pair("LAS ROZAS", GeoPoint(40.494215, -3.868181)),
        Pair("PINAR DE LAS ROZAS", GeoPoint(40.522282, -3.882258)),
        Pair("TORRELODONES", GeoPoint(40.574559, -3.956577)),
        Pair("EL ESCORIAL", GeoPoint(40.585279, -4.132418)),
        Pair("LAS MATAS", GeoPoint(40.552415, -3.896791)),
        Pair("SAN YAGO", GeoPoint(40.617864, -4.031106)),
        Pair("LAS ZORRERAS-NAVALQUEJIGO", GeoPoint(40.609265, -4.046336)),
        Pair("ARANJUEZ", GeoPoint(40.0347255, -3.6182069)),
        Pair("PINTO", GeoPoint(40.2429829, -3.7036534)),
        Pair("VALDEMORO", GeoPoint(40.1958184, -3.6646737)),
        Pair("CIEMPOZUELOS", GeoPoint(40.1590641, -3.610221)),
        Pair("VILLALBA DE GUADARRAMA", GeoPoint(40.626522, -4.00812)),
        Pair("LOS NEGRALES", GeoPoint(40.63856, -4.021915)),
        Pair("GALAPAGAR-LA NAVATA", GeoPoint(40.600159, -3.981913)),
        Pair("ALPEDRETE", GeoPoint(40.658096, -4.034996)),
        Pair("COLLADO MEDIANO", GeoPoint(40.692757, -4.035894)),
        Pair("LOS MOLINOS-GUADARRAMA", GeoPoint(40.706598, -4.067179)),
        Pair("CERCEDILLA", GeoPoint(40.737516, -4.066481)),
        Pair("PUERTO DE NAVACERRADA", GeoPoint(40.784445, -4.004772)),
        Pair("TRES CANTOS", GeoPoint(40.598596, -3.7156)),
        Pair("COLMENAR VIEJO", GeoPoint(40.645211, -3.776617)),
        Pair("LA GARENA", GeoPoint(40.4807624, -3.3919677)),
        Pair("ALCALA DE HENARES", GeoPoint(40.488976, -3.3664702)),
        Pair("ALCALA DE HENARES-UNIVERSIDAD", GeoPoint(40.5054503, -3.3353684)),
        Pair("SAN FERNANDO DE HENARES", GeoPoint(40.4424319, -3.5342411)),
        Pair("TORREJON DE ARDOZ", GeoPoint(40.4547456, -3.4797065)),
        Pair("SOTO DEL HENARES", GeoPoint(40.464383, -3.440614)),
        Pair("MECO", GeoPoint(40.534668, -3.2985719)),
        Pair("GETAFE-SECTOR 3", GeoPoint(40.288252, -3.737529)),
        Pair("GETAFE-CENTRO", GeoPoint(40.309974, -3.733989)),
        Pair("LAS MARGARITAS", GeoPoint(40.323041, -3.727278)),
        Pair("GETAFE-INDUSTRIAL", GeoPoint(40.3055338, -3.7073714)),
        Pair("EL CASAR", GeoPoint(40.3184029, -3.7092335)),
        Pair("LEGANES", GeoPoint(40.328633, -3.771162)),
        Pair("PARQUE POLVORANCA", GeoPoint(40.312544, -3.783546)),
        Pair("ZARZAQUEMADA", GeoPoint(40.3409732, -3.7482259)),
        Pair("ALCORCON", GeoPoint(40.350199, -3.831678)),
        Pair("LAS RETAMAS", GeoPoint(40.341869, -3.842311)),
        Pair("SAN JOSE DE VALDERAS", GeoPoint(40.356574, -3.815577)),
        Pair("MOSTOLES", GeoPoint(40.328724, -3.863478)),
        Pair("MOSTOLES-EL SOTO", GeoPoint(40.330971, -3.882441)),
        Pair("FUENLABRADA", GeoPoint(40.283135, -3.799565)),
        Pair("LA SERNA-FUENLABRADA", GeoPoint(40.296725, -3.792477)),
        Pair("HUMANES", GeoPoint(40.255565, -3.828334)),
        Pair("PARLA", GeoPoint(40.241032, -3.769312)),
        Pair("LOS COTOS", GeoPoint(40.822239, -3.964546))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar locationTextView
        locationTextView = findViewById(R.id.locationTextView)

        // Inicializar el Handler
        handler = Handler()

        val navView: BottomNavigationView = findViewById(R.id.nav_view)
        navView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> true
                R.id.navigation_map -> {
                    latestLocation?.let {
                        val intent = Intent(this, OpenStreetMapActivity::class.java)
                        val bundle = Bundle().apply { putParcelable("location", it) }
                        intent.putExtra("locationBundle", bundle)
                        startActivity(intent)
                    } ?: Log.e(TAG, "Location not set yet.")
                    true
                }
                R.id.navigation_list -> {
                    latestLocation?.let {
                        calculateAndShowClosestStations()
                    } ?: Toast.makeText(this, "Location not set yet.", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val userIdentifier = getUserIdentifier()
        if (userIdentifier == null) {
            askForUserIdentifier()
        } else {
            Toast.makeText(this, "User ID: $userIdentifier", Toast.LENGTH_LONG).show()
        }

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), locationPermissionCode)
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
        }
    }

    private fun calculateAndShowClosestStations() {
        try {
            latestLocation?.let { currentLocation ->
                // Log para verificar la ubicación actual
                Log.d(TAG, "Current Location: ${currentLocation.latitude}, ${currentLocation.longitude}")

                val distances = renfeStations.map { station ->
                    val distance = calculateDistanceInKm(
                        currentLocation.latitude, currentLocation.longitude,
                        station.second.latitude, station.second.longitude
                    )
                    Pair(station.first, distance)
                }.sortedBy { it.second }
                    .take(10)

                // Debug log para distancias
                distances.forEach { station ->
                    Log.d(TAG, "Station: ${station.first}, Distance: ${station.second} km")
                }

                val intent = Intent(this, RenfeStationActivity::class.java).apply {
                    putExtra("stationList", distances.map { it.first }.toTypedArray())
                    putExtra("distanceList", distances.map { it.second }.toDoubleArray())
                }
                startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating or showing closest stations", e)
            Toast.makeText(this, "Error calculating distances", Toast.LENGTH_SHORT).show()
        }
    }

    private fun calculateDistanceInKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadiusKm = 6371
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val lat1Rad = Math.toRadians(lat1)
        val lat2Rad = Math.toRadians(lat2)

        val a = sin(dLat / 2) * sin(dLat / 2) +
                sin(dLon / 2) * sin(dLon / 2) * cos(lat1Rad) * cos(lat2Rad)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusKm * c
    }

    private fun getUserIdentifier(): String? {
        val sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE)
        return sharedPreferences.getString("user_identifier", null)
    }

    private fun askForUserIdentifier() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Enter User Identifier")

        val input = EditText(this)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, which ->
            val userIdentifier = input.text.toString()
            saveUserIdentifier(userIdentifier)
        }
        builder.setNegativeButton("Cancel") { dialog, which -> dialog.cancel() }

        builder.show()
    }

    private fun saveUserIdentifier(userIdentifier: String) {
        val sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            putString("user_identifier", userIdentifier)
            apply()
        }
    }

    override fun onLocationChanged(location: Location) {
        latestLocation = location
        // Mostrar la ubicación actual en el TextView
        locationTextView.text = "Su ubicación actual es: ${location.latitude}, ${location.longitude}"
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
                }
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Detener el handler cuando la actividad se destruye
        handler.removeCallbacksAndMessages(null)
    }

    // Método para iniciar la actualización de la ubicación
    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)

        // Programar la próxima actualización de la ubicación después de 5 minutos
        handler.postDelayed({
            startLocationUpdates()
        }, 5 * 60 * 1000) // 5 minutos en milisegundos
    }

}
