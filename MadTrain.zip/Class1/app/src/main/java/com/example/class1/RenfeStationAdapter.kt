package com.example.class1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.osmdroid.util.GeoPoint

class RenfeStationAdapter(private val stationList: List<Pair<String, GeoPoint>>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_TYPE_HEADER = 0
    private val VIEW_TYPE_ITEM = 1

    private var headerView: View? = null
    private var myLocation: GeoPoint? = null

    fun setHeaderView(view: View) {
        headerView = view
        notifyItemInserted(0)
    }

    fun setMyLocation(location: GeoPoint) {
        myLocation = location
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_HEADER -> HeaderViewHolder(headerView!!)
            VIEW_TYPE_ITEM -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.listview_item, parent, false)
                ItemViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            VIEW_TYPE_HEADER -> {
                // No se hace nada especial para el encabezado, ya que está inflado y configurado externamente
            }
            VIEW_TYPE_ITEM -> {
                val itemHolder = holder as ItemViewHolder
                val station = stationList[position - 1] // Se resta 1 para omitir el encabezado
                itemHolder.bind(station)
            }
        }
    }

    override fun getItemCount(): Int {
        return stationList.size + if (headerView == null) 0 else 1
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0 && headerView != null) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
    }

    inner class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val stationNameTextView: TextView = itemView.findViewById(R.id.stationName)
        private val distanceTextView: TextView = itemView.findViewById(R.id.stationDistance)

        fun bind(station: Pair<String, GeoPoint>) {
            stationNameTextView.text = station.first
            myLocation?.let { location ->
                // Calcular la distancia desde la ubicación proporcionada hasta la estación y mostrarla en el TextView distanceTextView
                val distance = calculateDistance(station.second, location)
                distanceTextView.text = "%.2f km".format(distance)
            }
        }

        private fun calculateDistance(stationLocation: GeoPoint, myLocation: GeoPoint): Double {
            val earthRadius = 6371.0 // Radio de la Tierra en kilómetros
            val lat1 = Math.toRadians(myLocation.latitude)
            val lon1 = Math.toRadians(myLocation.longitude)
            val lat2 = Math.toRadians(stationLocation.latitude)
            val lon2 = Math.toRadians(stationLocation.longitude)

            val dLat = lat2 - lat1
            val dLon = lon2 - lon1

            val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(lat1) * Math.cos(lat2) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2)

            val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

            return earthRadius * c
        }
    }
}
