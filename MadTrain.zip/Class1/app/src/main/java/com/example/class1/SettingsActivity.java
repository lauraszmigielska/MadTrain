package com.example.class1;

public class SettingsActivity {
}
